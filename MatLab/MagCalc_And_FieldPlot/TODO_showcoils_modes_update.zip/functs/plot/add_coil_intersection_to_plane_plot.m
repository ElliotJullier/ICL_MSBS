function h = add_coil_intersection_to_plane_plot(ax, planeReq, geometry, colorVal, varargin)
%ADD_COIL_INTERSECTION_TO_PLANE_PLOT Draw coil/plane intersection boxes.
%
% This is the planar/intersection ShowCoils mode for plane plots. It samples
% the already-defined query plane, uses the analytic annular-cylinder coil
% mask, then draws one semi-transparent rectangular box around each connected
% material intersection region.
%
% This intentionally supports analytic coil geometry only. Mesh/STL-only
% geometry does not contain outerRadius, innerRadius, height, or a reliable
% analytic bore definition, so it is skipped before this function is called.

p = inputParser;
addParameter(p, "Alpha", 0.55, @(x)isnumeric(x) && isscalar(x));
addParameter(p, "DisplayName", "Coils", @(x)isstring(x) || ischar(x));
parse(p, varargin{:});
opts = p.Results;

h = gobjects(0);

if nargin < 4 || isempty(colorVal)
    colourOrder = get(ax, "ColorOrder");
    colorVal = colourOrder(1, :);
end
colorVal = reshape(double(colorVal), 1, 3);
edgeColor = max(0, 0.65*colorVal);

if isempty(geometry) || ~isfield(planeReq, 'X') || ~isfield(planeReq, 'Y') || ~isfield(planeReq, 'Z')
    return
end

X = planeReq.X;
Y = planeReq.Y;
Z = planeReq.Z;

if ~ismatrix(X) || ~isequal(size(X), size(Y), size(Z)) || numel(X) < 4
    return
end

pts = [X(:).'; Y(:).'; Z(:).'];
mask = coil_material_mask(pts, geometry);
materialMask = reshape(mask.material, size(X));

if ~any(materialMask, "all")
    return
end

components = connected_components_2d(materialMask);
if isempty(components)
    return
end

[origin, basis] = plane_basis_from_points(X, Y, Z);
uv = basis.' * (pts - origin);
U = reshape(uv(1,:), size(X));
V = reshape(uv(2,:), size(X));

[du, dv] = estimate_plane_spacing(U, V);

for c = 1:numel(components)
    rows = components(c).rows;
    cols = components(c).cols;

    uMin = min(U(sub2ind(size(U), rows, cols)), [], 'omitnan') - 0.5*du;
    uMax = max(U(sub2ind(size(U), rows, cols)), [], 'omitnan') + 0.5*du;
    vMin = min(V(sub2ind(size(V), rows, cols)), [], 'omitnan') - 0.5*dv;
    vMax = max(V(sub2ind(size(V), rows, cols)), [], 'omitnan') + 0.5*dv;

    if ~all(isfinite([uMin, uMax, vMin, vMax])) || uMin == uMax || vMin == vMax
        continue
    end

    uvCorners = [uMin, uMax, uMax, uMin; ...
                 vMin, vMin, vMax, vMax];
    xyzCorners = origin + basis * uvCorners;

    h(end+1,1) = patch(ax, ...
        xyzCorners(1,:), ...
        xyzCorners(2,:), ...
        xyzCorners(3,:), ...
        colorVal, ...
        'FaceAlpha', opts.Alpha, ...
        'EdgeColor', edgeColor, ...
        'LineWidth', 1.25, ...
        'DisplayName', char(string(opts.DisplayName)), ...
        'HandleVisibility', 'off', ...
        'HitTest', 'off'); %#ok<AGROW>
end
end

function components = connected_components_2d(mask)
%CONNECTED_COMPONENTS_2D Find 4-connected true regions without toolboxes.

mask = logical(mask);
[nRows, nCols] = size(mask);
visited = false(nRows, nCols);
components = struct("rows", {}, "cols", {});

for r0 = 1:nRows
    for c0 = 1:nCols
        if ~mask(r0, c0) || visited(r0, c0)
            continue
        end

        queueR = zeros(numel(mask), 1);
        queueC = zeros(numel(mask), 1);
        head = 1;
        tail = 1;
        queueR(tail) = r0;
        queueC(tail) = c0;
        visited(r0, c0) = true;

        compRows = zeros(numel(mask), 1);
        compCols = zeros(numel(mask), 1);
        n = 0;

        while head <= tail
            r = queueR(head);
            c = queueC(head);
            head = head + 1;

            n = n + 1;
            compRows(n) = r;
            compCols(n) = c;

            neighbours = [r-1, c; r+1, c; r, c-1; r, c+1];
            for j = 1:4
                rr = neighbours(j, 1);
                cc = neighbours(j, 2);

                if rr < 1 || rr > nRows || cc < 1 || cc > nCols
                    continue
                end
                if visited(rr, cc) || ~mask(rr, cc)
                    continue
                end

                tail = tail + 1;
                queueR(tail) = rr;
                queueC(tail) = cc;
                visited(rr, cc) = true;
            end
        end

        components(end+1).rows = compRows(1:n); %#ok<AGROW>
        components(end).cols = compCols(1:n);
    end
end
end

function [origin, basis] = plane_basis_from_points(X, Y, Z)
%PLANE_BASIS_FROM_POINTS Estimate an orthonormal basis for a sampled plane.

P = [X(:).'; Y(:).'; Z(:).'];
origin = mean(P, 2, 'omitnan');
Pc = P - origin;

[U, ~, ~] = svd(Pc, 'econ');

if size(U, 2) >= 2
    basis = U(:, 1:2);
else
    basis = eye(3, 2);
end
end

function [du, dv] = estimate_plane_spacing(U, V)
%ESTIMATE_PLANE_SPACING Estimate median sampling spacing in plane coords.

uVals = unique(round(U(:), 12));
vVals = unique(round(V(:), 12));

du = median(abs(diff(sort(uVals))), 'omitnan');
dv = median(abs(diff(sort(vVals))), 'omitnan');

if isempty(du) || ~isfinite(du) || du <= 0
    du = 0;
end
if isempty(dv) || ~isfinite(dv) || dv <= 0
    dv = 0;
end
end
