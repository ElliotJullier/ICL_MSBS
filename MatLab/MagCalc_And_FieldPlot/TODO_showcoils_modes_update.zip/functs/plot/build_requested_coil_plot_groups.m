function coilGroups = build_requested_coil_plot_groups(records, overlayMode)
%BUILD_REQUESTED_COIL_PLOT_GROUPS Group requested coil overlays by geometry.
%
% coilGroups = build_requested_coil_plot_groups(records, overlayMode)
%
% overlayMode controls which ShowCoils requests are selected:
%   "full"
%       Select ShowCoils=true/"full" records. Geometry can be analytic or
%       mesh/STL because full coil plotting uses stored Faces/Vertices.
%
%   "intersection"
%       Select ShowCoils="planar"/"intersection" records. Geometry must be
%       analytic because the coil/plane boxes are computed from outerRadius,
%       innerRadius, height, and pose.
%
%   "line"
%       Select ShowCoils=true/"full" records for line-plot coil shading.
%       Geometry must be analytic. ShowCoils="intersection" is ignored for
%       line plots with a warning.
%
% Records with equivalent coil geometry are grouped so the same coil set is
% plotted only once. Synthetic records with source geometries are expanded
% into one candidate source per input case.

if nargin < 2 || isempty(overlayMode)
    overlayMode = "full";
end
overlayMode = lower(string(overlayMode));

coilGroups = struct( ...
    "geometry", {}, ...
    "records", {}, ...
    "recordIndices", {}, ...
    "caseNames", {}, ...
    "legendLabel", {}, ...
    "signature", {}, ...
    "overlayMode", {});

if isempty(records)
    return
end

for k = 1:numel(records)
    record = records{k};
    showMode = record_show_coils_mode(record);

    if ~record_selected_for_overlay_mode(showMode, overlayMode, record)
        continue
    end

    sources = coil_geometry_sources_for_record(record);

    if isempty(sources)
        warning("ShowCoils=%s was requested for case '%s', but no usable coil geometry was available. Coil overlay skipped for that record.", ...
            showMode, string(record.caseName));
        continue
    end

    for s = 1:numel(sources)
        source = sources(s);

        if ~source.hasUsableGeometry
            warn_missing_geometry(record, source, showMode);
            continue
        end

        if overlayMode == "intersection" || overlayMode == "line"
            if ~has_analytic_coil_geometry(source.geometry)
                warn_nonanalytic_geometry(record, source, overlayMode, showMode);
                continue
            end
        end

        coilGroups = add_source_to_coil_groups(coilGroups, record, k, source, overlayMode);
    end
end

% Finalise stable, unique case names and legend labels.
for g = 1:numel(coilGroups)
    coilGroups(g).caseNames = unique(coilGroups(g).caseNames, "stable");
end

if numel(coilGroups) == 1
    coilGroups(1).legendLabel = "Coils";
elseif numel(coilGroups) > 1
    for g = 1:numel(coilGroups)
        caseList = "(" + coilGroups(g).caseNames + ")";
        coilGroups(g).legendLabel = "Coils: Case " + join(caseList, " and ");
    end
end
end

function tf = record_selected_for_overlay_mode(showMode, overlayMode, record)
tf = false;

switch overlayMode
    case "full"
        tf = showMode == "full";

    case "intersection"
        tf = showMode == "intersection";

    case "line"
        if showMode == "intersection"
            warning("ShowCoils='%s' was requested for line query '%s' in case '%s'. Planar/intersection coil overlays are only implemented for plane plots; line coil overlay skipped.", ...
                showMode, query_label(record), string(record.caseName));
            return
        end
        tf = showMode == "full";

    otherwise
        error("Unknown coil overlay mode '%s'.", overlayMode);
end
end

function coilGroups = add_source_to_coil_groups(coilGroups, record, recordIndex, source, overlayMode)
sig = build_coil_signature(source.geometry);

matchIdx = 0;
for g = 1:numel(coilGroups)
    if signatures_match(coilGroups(g).signature, sig)
        matchIdx = g;
        break
    end
end

if matchIdx == 0
    matchIdx = numel(coilGroups) + 1;
    coilGroups(matchIdx).geometry = source.geometry;
    coilGroups(matchIdx).records = {record};
    coilGroups(matchIdx).recordIndices = recordIndex;
    coilGroups(matchIdx).caseNames = string(source.caseName);
    coilGroups(matchIdx).legendLabel = "Coils";
    coilGroups(matchIdx).signature = sig;
    coilGroups(matchIdx).overlayMode = overlayMode;
else
    coilGroups(matchIdx).records{end+1} = record;
    coilGroups(matchIdx).recordIndices(end+1) = recordIndex;
    coilGroups(matchIdx).caseNames(end+1) = string(source.caseName);
end
end

function mode = record_show_coils_mode(record)
mode = "none";

if isfield(record, "query") && ...
   isfield(record.query, "plot") && ...
   isfield(record.query.plot, "showCoils") && ...
   ~isempty(record.query.plot.showCoils)
    mode = normalise_show_coils_mode(record.query.plot.showCoils);
end
end

function mode = normalise_show_coils_mode(value)
if isempty(value)
    mode = "none";
    return
end

if islogical(value) || isnumeric(value)
    if ~isscalar(value)
        error("ShowCoils must be a scalar logical/numeric value or a string mode.");
    end
    if logical(value)
        mode = "full";
    else
        mode = "none";
    end
    return
end

value = lower(strtrim(string(value)));
if numel(value) ~= 1
    error("ShowCoils must be a scalar logical/numeric value or a string mode.");
end

switch value
    case {"false", "off", "none", "no", "0"}
        mode = "none";
    case {"true", "on", "full", "body", "1"}
        mode = "full";
    case {"planar", "plane", "intersection", "intersect", "slice"}
        mode = "intersection";
    otherwise
        error("Unknown ShowCoils mode '%s'. Use false, true, 'planar', or 'intersection'.", value);
end
end

function sources = coil_geometry_sources_for_record(record)
%COIL_GEOMETRY_SOURCES_FOR_RECORD Return one or more source geometries.
%
% Normal record:
%   one source, labelled with record.caseName.
%
% Synthetic difference record with record.synthetic.coilGeometrySources:
%   one source per input case, labelled with source.caseName.

sources = struct( ...
    "caseName", {}, ...
    "hasUsableGeometry", {}, ...
    "geometry", {});

if isfield(record, "synthetic") && ...
   isstruct(record.synthetic) && ...
   isfield(record.synthetic, "coilGeometrySources") && ...
   ~isempty(record.synthetic.coilGeometrySources)

    rawSources = record.synthetic.coilGeometrySources;

    for k = 1:numel(rawSources)
        source = struct();

        if isfield(rawSources(k), "caseName") && strlength(string(rawSources(k).caseName)) > 0
            source.caseName = string(rawSources(k).caseName);
        else
            source.caseName = string(record.caseName) + " source " + string(k);
        end

        if isfield(rawSources(k), "geometry") && ~isempty(rawSources(k).geometry)
            source.geometry = rawSources(k).geometry;
        else
            source.geometry = empty_geometry();
        end

        if isfield(rawSources(k), "hasUsableGeometry") && ~isempty(rawSources(k).hasUsableGeometry)
            source.hasUsableGeometry = logical(rawSources(k).hasUsableGeometry);
        else
            source.hasUsableGeometry = has_usable_geometry(source.geometry);
        end

        sources(end+1) = source; %#ok<AGROW>
    end

    return
end

source = struct();
source.caseName = string(record.caseName);

if isfield(record, "geometry") && ~isempty(record.geometry)
    source.geometry = record.geometry;
else
    source.geometry = empty_geometry();
end

source.hasUsableGeometry = has_usable_geometry(source.geometry);
sources = source;
end

function tf = has_usable_geometry(geometry)
tf = isstruct(geometry) && ...
     isfield(geometry, "coil") && ...
     ~isempty(geometry.coil);
end

function tf = has_analytic_coil_geometry(geometry)
%HAS_ANALYTIC_COIL_GEOMETRY True only when every coil has annular-cylinder
%metadata needed by coil_material_mask and planar intersection boxes.

tf = has_usable_geometry(geometry) && ...
     isfield(geometry, "coilSpec") && ...
     isstruct(geometry.coilSpec);

if ~tf
    return
end

for k = 1:numel(geometry.coil)
    coil = geometry.coil(k);

    if ~isfield(coil, "coilType") || isempty(coil.coilType) || ...
       ~isfield(coil, "pose") || isempty(coil.pose)
        tf = false;
        return
    end

    coilType = string(coil.coilType);
    if ~isfield(geometry.coilSpec, coilType)
        tf = false;
        return
    end

    spec = geometry.coilSpec.(coilType);
    required = ["outerRadius", "innerRadius", "height"];
    for r = 1:numel(required)
        name = required(r);
        if ~isfield(spec, name) || isempty(spec.(name)) || ~isnumeric(spec.(name))
            tf = false;
            return
        end
    end
end
end

function geometry = empty_geometry()
geometry = struct();
geometry.windTunnel = [];
geometry.coilSpec = struct();
geometry.coil = struct([]);
end

function sig = build_coil_signature(geometry)
%BUILD_COIL_SIGNATURE Build an order-independent coil-geometry signature.
%
% Coil order and names are ignored. Coil type, pose, analytic dimensions,
% and fallback shape bounds are used.

n = numel(geometry.coil);
sig = strings(n, 1);

for k = 1:n
    coil = geometry.coil(k);

    coilType = "";
    if isfield(coil, "coilType") && ~isempty(coil.coilType)
        coilType = string(coil.coilType);
    end

    vals = [];

    if isfield(geometry, "coilSpec") && isstruct(geometry.coilSpec) && ...
       strlength(coilType) > 0 && isfield(geometry.coilSpec, coilType)

        spec = geometry.coilSpec.(coilType);
        vals = [vals, get_numeric_field(spec, "outerRadius")]; %#ok<AGROW>
        vals = [vals, get_numeric_field(spec, "innerRadius")]; %#ok<AGROW>
        vals = [vals, get_numeric_field(spec, "height")]; %#ok<AGROW>
        vals = [vals, get_numeric_field(spec, "turns")]; %#ok<AGROW>
    end

    if isfield(coil, "pose") && ~isempty(coil.pose)
        vals = [vals, double(coil.pose(:).')]; %#ok<AGROW>
    end

    if isfield(coil, "shape") && isstruct(coil.shape) && ...
       isfield(coil.shape, "Vertices") && ~isempty(coil.shape.Vertices)

        vertices = double(coil.shape.Vertices);
        xyzMin = min(vertices, [], 1);
        xyzMax = max(vertices, [], 1);
        xyzCtr = 0.5*(xyzMin + xyzMax);
        xyzSize = xyzMax - xyzMin;
        vals = [vals, xyzCtr, xyzSize]; %#ok<AGROW>
    end

    vals = round(vals, 12);
    sig(k) = coilType + ":" + join(string(vals), ",");
end

sig = sort(sig);
end

function val = get_numeric_field(s, name)
if isfield(s, name) && ~isempty(s.(name)) && isnumeric(s.(name))
    val = double(s.(name));
else
    val = NaN;
end
end

function tf = signatures_match(a, b)
tf = numel(a) == numel(b) && all(a == b);
end

function warn_missing_geometry(record, source, showMode)
if isfield(record, "synthetic")
    warning("ShowCoils=%s was requested for synthetic case '%s', but source case '%s' has no usable coil geometry. Coil overlay skipped for that source.", ...
        showMode, string(record.caseName), string(source.caseName));
else
    warning("ShowCoils=%s was requested for case '%s', but no usable coil geometry was available. Coil overlay skipped for that record.", ...
        showMode, string(record.caseName));
end
end

function warn_nonanalytic_geometry(record, source, overlayMode, showMode)
if overlayMode == "intersection"
    reason = "planar/intersection coil overlays require analytic coil geometry";
else
    reason = "line coil overlays require analytic coil geometry";
end

if isfield(record, "synthetic")
    warning("ShowCoils=%s was requested for synthetic case '%s', but source case '%s' uses non-analytic coil geometry; %s. Coil overlay skipped for that source.", ...
        showMode, string(record.caseName), string(source.caseName), reason);
else
    warning("ShowCoils=%s was requested for case '%s', but it uses non-analytic coil geometry; %s. Coil overlay skipped for that record.", ...
        showMode, string(record.caseName), reason);
end
end

function label = query_label(record)
if isfield(record, "queryName") && strlength(string(record.queryName)) > 0
    label = string(record.queryName);
else
    label = "query " + string(record.queryIndex);
end
end
