function mask = coil_material_mask(pointsGlobal, geometry)
%COIL_MATERIAL_MASK Test points against analytic coil envelopes/material.
%
% pointsGlobal is 3xN. Output masks are 1xN logical arrays.
%
% Only analytic annular-cylinder coil definitions are considered. Mesh/STL
% geometry is deliberately ignored here because line and planar-intersection
% overlays require outerRadius, innerRadius, height, and pose.

nPts = size(pointsGlobal, 2);
mask = struct();
mask.outer = false(1, nPts);
mask.bore = false(1, nPts);
mask.material = false(1, nPts);

if nargin < 2 || isempty(geometry) || ~isstruct(geometry) || ...
   ~isfield(geometry, "coil") || isempty(geometry.coil) || ...
   ~isfield(geometry, "coilSpec") || ~isstruct(geometry.coilSpec)
    return
end

for k = 1:numel(geometry.coil)
    coil = geometry.coil(k);

    if ~isfield(coil, "coilType") || isempty(coil.coilType) || ...
       ~isfield(coil, "pose") || isempty(coil.pose)
        continue
    end

    coilType = string(coil.coilType);
    if ~isfield(geometry.coilSpec, coilType)
        continue
    end

    spec = geometry.coilSpec.(coilType);
    if ~has_required_analytic_spec(spec)
        continue
    end

    ptsLocal = coord_global2local(pointsGlobal, coil.pose);
    rho = hypot(ptsLocal(1,:), ptsLocal(2,:));
    zc  = ptsLocal(3,:);

    insideOuter = (rho <= spec.outerRadius) & (abs(zc) <= spec.height/2);
    insideBore  = (rho <  spec.innerRadius) & (abs(zc) <= spec.height/2);

    mask.outer = mask.outer | insideOuter;
    mask.bore = mask.bore | insideBore;
    mask.material = mask.material | (insideOuter & ~insideBore);
end
end

function tf = has_required_analytic_spec(spec)
required = ["outerRadius", "innerRadius", "height"];
tf = true;

for k = 1:numel(required)
    name = required(k);
    if ~isfield(spec, name) || isempty(spec.(name)) || ~isnumeric(spec.(name))
        tf = false;
        return
    end
end
end
