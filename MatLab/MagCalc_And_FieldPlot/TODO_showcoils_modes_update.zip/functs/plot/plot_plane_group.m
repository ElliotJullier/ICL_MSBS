function plot_plane_group(groupStruct, plotStyle)
% PLOT_PLANE_GROUP Plot one group of plane records.
%
% ShowCoils modes:
%   false/"false"/"none"
%       no coil overlay
%   true/"true"/"full"
%       full 3D coil bodies using stored coil shapes
%   "planar"/"intersection"
%       analytic coil/plane intersection boxes only
%
% Records with ShowCoils=false do not cause an error. Requested coil
% geometries are grouped by equivalent coil position/setup so overlapping
% coil sets are plotted only once.
reqs = groupStruct.requests;
if isempty(reqs)
    return
end

refLabel = "";
for k = 1:numel(reqs)
    thisLabel = string(reqs{k}.dataName);
    if refLabel == ""
        refLabel = thisLabel;
    elseif thisLabel ~= refLabel
        error("Grouped planes must share the same plotted quantity. Split them into different groups.");
    end
end

fullCoilGroups = build_requested_coil_plot_groups(reqs, "full");
intersectionCoilGroups = build_requested_coil_plot_groups(reqs, "intersection");

singlePlane = isscalar(reqs);

fig = figure;
ax = axes('Parent', fig);
hold(ax, 'on');
axis(ax, 'equal');
box(ax, 'on');
grid(ax, 'on');

qFile = "";
if isfield(plotStyle, "Q_file")
    qFile = string(plotStyle.Q_file);
end

[~, qFileBase, ~] = fileparts(qFile);
if strlength(qFileBase) == 0
    qFileBase = "Q output";
end

groupLabel = string(groupStruct.key);
isUngrouped = startsWith(groupLabel, "ungrouped");

if isUngrouped
    figName = "Plane: " + string(reqs{1}.caseName) + " - " + qFileBase;
else
    figName = "Plane group " + groupLabel + " - " + qFileBase;
end

set(fig, "Name", char(figName));

for k = 1:numel(reqs)
    surf(ax, reqs{k}.X, reqs{k}.Y, reqs{k}.Z, reqs{k}.data, ...
        'EdgeColor', 'none', ...
        'DisplayName', char(string(reqs{k}.caseName) + ": " + string(reqs{k}.queryName)));
end

plot_coil_groups_on_plane_axes(ax, fullCoilGroups, intersectionCoilGroups);

quantityClass = get_record_group_quantity_class(reqs);
set_clrbar(ax, plotStyle.clim.(quantityClass), refLabel);

if singlePlane
    set_plane_view(ax, reqs{1});
else
    view(ax, 3);
end

xlabel(ax, '$x$ [m]', 'Interpreter', 'latex');
ylabel(ax, '$y$ [m]', 'Interpreter', 'latex');
zlabel(ax, '$z$ [m]', 'Interpreter', 'latex');

if numel(reqs) > 1 || ~isempty(fullCoilGroups) || ~isempty(intersectionCoilGroups)
    legend(ax, 'show', 'Location', 'best', 'Interpreter', 'none');
end

title(ax, figName, "Interpreter", "none");

if exist('write_plot_metadata_file', 'file') == 2
    write_plot_metadata_file(figName, reqs, plotStyle);
end

if isfield(plotStyle, "showOrientationReadout") && plotStyle.showOrientationReadout
    attach_view_report_callback(ax);
end
end


% -------------------- LOCAL HELPER FUNCTION(S) --------------------------
function plot_coil_groups_on_plane_axes(ax, fullCoilGroups, intersectionCoilGroups)
%PLOT_COIL_GROUPS_ON_PLANE_AXES Plot requested coil overlays.

nGroups = numel(fullCoilGroups) + numel(intersectionCoilGroups);
if nGroups == 0
    return
end

colourOrder = get(ax, "ColorOrder");
if isempty(colourOrder)
    colourOrder = lines(max(1, nGroups));
end

colourIndex = 0;

for g = 1:numel(fullCoilGroups)
    colourIndex = colourIndex + 1;
    colour = colourOrder(mod(colourIndex-1, size(colourOrder, 1)) + 1, :);

    hCoils = plot_coils_transparent_edges(ax, fullCoilGroups(g).geometry, ...
        "Color", colour, ...
        "Alpha", 0.55, ...
        "DisplayName", fullCoilGroups(g).legendLabel);

    expose_one_legend_handle(hCoils, fullCoilGroups(g).legendLabel);
end

for g = 1:numel(intersectionCoilGroups)
    colourIndex = colourIndex + 1;
    colour = colourOrder(mod(colourIndex-1, size(colourOrder, 1)) + 1, :);
    representativeRecord = intersectionCoilGroups(g).records{1};

    hCoils = add_coil_intersection_to_plane_plot(ax, ...
        representativeRecord, ...
        intersectionCoilGroups(g).geometry, ...
        colour, ...
        "Alpha", 0.55, ...
        "DisplayName", intersectionCoilGroups(g).legendLabel);

    expose_one_legend_handle(hCoils, intersectionCoilGroups(g).legendLabel);
end
end

function expose_one_legend_handle(h, label)
validHandles = h(isgraphics(h));
if isempty(validHandles)
    return
end

set(validHandles, "HandleVisibility", "off");
set(validHandles(1), ...
    "DisplayName", char(string(label)), ...
    "HandleVisibility", "on");
end

function quantityClass = get_record_group_quantity_class(reqs)
%GET_RECORD_GROUP_QUANTITY_CLASS Return "field" or "gradient" for a group.

if isempty(reqs)
    quantityClass = "field";
    return
end

classes = strings(1, numel(reqs));

for k = 1:numel(reqs)
    r = reqs{k};

    if isfield(r, "query") && isfield(r.query, "quantity")
        q = lower(string(r.query.quantity));
    else
        q = "";
    end

    if q == "gradient" || startsWith(string(r.dataName), "dB")
        classes(k) = "gradient";
    else
        classes(k) = "field";
    end
end

if numel(unique(classes)) > 1
    error("Grouped plane plots cannot mix field and gradient quantities. Use separate groups.");
end

quantityClass = classes(1);
end
