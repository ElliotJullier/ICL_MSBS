function q = validate_and_complete_query(q, model)
%VALIDATE_AND_COMPLETE_QUERY Fill defaults and validate one query.
%
% This function is the public contract for the internal query structure. It
% fills optional fields, validates common fields, then checks whether the
% selected model can evaluate the requested query.
%
% q.plot.showCoils supports these values:
%   false, "false", "off", 0
%       no coil overlay
%   true, "true", "on", "full", 1
%       full 3D coil body on plane plots; sampled analytic coil shading on
%       line plots
%   "planar", "intersection", "intersect"
%       analytic coil/plane intersection boxes on plane plots only

if ~isfield(q, "type")
    error("Query is missing q.type.");
end
if ~isfield(q, "quantity")
    q.quantity = "field";
end
if ~isfield(q, "component")
    error("Query is missing q.component.");
end

q.type = lower(string(q.type));
q.quantity = lower(string(q.quantity));

if ~isfield(q, "name")
    q.name = "";
end
q.name = string(q.name);

if ~isfield(q, "plot") || isempty(q.plot)
    q.plot = struct();
end
if ~isfield(q.plot, "group")
    q.plot.group = [];
end
if ~isfield(q.plot, "inOverview")
    q.plot.inOverview = false;
end
q.plot.inOverview = logical(q.plot.inOverview);

if ~isfield(q.plot, "showCoils")
    q.plot.showCoils = "none";
end
q.plot.showCoils = normalise_show_coils_mode(q.plot.showCoils);

validate_query_fields(q);
validate_query_for_model(q, model);
end

function validate_query_fields(q)
switch q.type
    case "line"
        required = ["start", "end", "nPoints"];
    case "fundamental_plane"
        required = ["plane", "planeOffset"];
        if ~any(lower(string(q.plane)) == ["xy", "xz", "yz"])
            error('q.plane must be "xy", "xz", or "yz".');
        end
    case "custom_plane"
        required = ["point", "normal", "resolution"];
    otherwise
        error("Unknown query type: %s", q.type);
end

for k = 1:numel(required)
    if ~isfield(q, required(k))
        error("Query of type '%s' is missing q.%s.", q.type, required(k));
    end
end

if q.quantity == "gradient"
    if ~isfield(q, "gradientDirection")
        q.gradientDirection = [];
    end
    if q.type ~= "line" && isempty(q.gradientDirection)
        error("GradientDirection is required for non-line gradient queries.");
    end
elseif q.quantity ~= "field"
    error("q.quantity must be 'field' or 'gradient'.");
end
end

function mode = normalise_show_coils_mode(value)
%NORMALISE_SHOW_COILS_MODE Convert user input to a coil plotting mode.

if isempty(value)
    mode = "none";
    return
end

if islogical(value) || isnumeric(value)
    if ~isscalar(value)
        error("ShowCoils must be a scalar logical/numeric value or a string mode.");
    end

    if logical(value)
        mode = "full";
    else
        mode = "none";
    end
    return
end

value = lower(strtrim(string(value)));
if numel(value) ~= 1
    error("ShowCoils must be a scalar logical/numeric value or a string mode.");
end

switch value
    case {"false", "off", "none", "no", "0"}
        mode = "none";
    case {"true", "on", "full", "body", "1"}
        mode = "full";
    case {"planar", "plane", "intersection", "intersect", "slice"}
        mode = "intersection";
    otherwise
        error("Unknown ShowCoils mode '%s'. Use false, true, 'planar', or 'intersection'.", value);
end
end
